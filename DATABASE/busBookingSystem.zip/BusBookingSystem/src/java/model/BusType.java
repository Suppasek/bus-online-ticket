/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Natsu
 */
public class BusType {
    String typeName;
    int seat_available;
    float price;
    
    public BusType() {
        
    }
    
    public void createBusType(String typeName, int seat_available, float price) {
        this.typeName = typeName;
        this.seat_available = seat_available;
        this.price = price;
    }
    
    public void insertBusType() throws ClassNotFoundException, SQLException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(sqllink, "root", "");
        PreparedStatement stmt = conn.prepareStatement("insert into bus_type(type_name, seat_available, price) values(?, ?, ?)");
        stmt.setString(1, typeName);
        stmt.setInt(2, seat_available);
        stmt.setFloat(3, price);
        stmt.executeUpdate();
        conn.close();
    } 
    
    
}
