/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Natsu
 */
public class BusTable {

    public int routeId;
    public String departures;
    public String destinations;
    public Date leavingDate;
    public Time leavingTime;
    public int busid;
    public int price;
    public String bustype;

    public BusTable() {

    }

    public void createTable(String departures, String destinations, Date leavingDate, int busid, Time leavingTime) {
        this.departures = departures;
        this.destinations = destinations;
        this.leavingDate = leavingDate;
        this.leavingTime = leavingTime;
        this.busid = busid;
    }

    public void insertTable() throws SQLException, ClassNotFoundException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection(sqllink, "root", "")) {
            PreparedStatement stmt = conn.prepareStatement("insert into bus_table(leaving_date, leaving_time, departures, destinations, bus_bid) values(?, ?, ?, ?, ?)");
            
            stmt.setDate(1, leavingDate);
            stmt.setTime(2, leavingTime);
            stmt.setString(3, departures);
            stmt.setString(4, destinations);
            stmt.setInt(5, busid);
            stmt.executeUpdate();
            ResultSet rs = stmt.executeQuery("select max(route_id) from bus_table");
            rs.next();
            routeId = rs.getInt("max(route_id)");
            rs = stmt.executeQuery("select seat_available from bus_type where type_id = (select bus_type_tid from bus where bus_id =" + busid + ")");
            Bus bus = new Bus();
            rs.next();
            int seatAvailable = rs.getInt("seat_available");
            bus.addSeat(seatAvailable, routeId, busid);
        }
    }

    public List<BusTable> getTableDetail(String departures, String destinations, Date date) throws SQLException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BusTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        Connection conn = DriverManager.getConnection(sqllink, "root", "");
        PreparedStatement stmt = conn.prepareStatement("select route_id, leaving_date, leaving_time, departures, destinations, typename, price, bus_bid"
                + " from bus_table join bus on (bus_table.bus_bid = bus.bus_id) join bus_type on (bus.bus_type_tid = bus_type.type_id)"
                + "where leaving_date = ? and departures = ? and destinations = ?");
        stmt.setDate(1, date);
        stmt.setString(2, departures);
        stmt.setString(3, destinations);
        ResultSet rs = stmt.executeQuery();
        List<BusTable> tablelist = new ArrayList<>();
        
        while (rs.next()) {
            BusTable table = new BusTable();
            table.createTable(departures, destinations, date, rs.getInt("bus_bid"), leavingTime);
            table.bustype = rs.getString("typename");
            table.price = rs.getInt("price");
            tablelist.add(table);
        }
        
        conn.close();
        return tablelist;
    }

    public int getRouteId() {
        return routeId;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    public String getDepartures() {
        return departures;
    }

    public void setDepartures(String departures) {
        this.departures = departures;
    }

    public String getDestinations() {
        return destinations;
    }

    public void setDestinations(String destinations) {
        this.destinations = destinations;
    }

    public Date getLeavingDate() {
        return leavingDate;
    }

    public void setLeavingDate(Date leavingDate) {
        this.leavingDate = leavingDate;
    }

    public Time getLeavingTime() {
        return leavingTime;
    }

    public void setLeavingTime(Time leavingTime) {
        this.leavingTime = leavingTime;
    }

    public int getBusid() {
        return busid;
    }

    public void setBusid(int busid) {
        this.busid = busid;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getBustype() {
        return bustype;
    }

    public void setBustype(String bustype) {
        this.bustype = bustype;
    }
}
