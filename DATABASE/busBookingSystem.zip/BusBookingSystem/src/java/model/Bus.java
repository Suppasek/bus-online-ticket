/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Natsu
 */
public class Bus {
    String licensePlate;
    int busType;
    
    public Bus() {
        
    }
    
    public void createBus(String licensePlate, int busType) {
        this.licensePlate = licensePlate;
        this.busType = busType;
    }
    
    public void addBus() throws ClassNotFoundException, SQLException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(sqllink, "root", "");
        PreparedStatement stmt = conn.prepareStatement("insert into bus(bus_type_tid, license_plate) values(?, ?)");     
        stmt.setInt(1, busType);
        stmt.setString(2, licensePlate);
        stmt.executeUpdate();
    }
    
        public void addSeat(int seatAvailable, int routeId, int busId) throws ClassNotFoundException, SQLException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(sqllink, "root", "");
        
        String query = "insert into bus_seat(seat_number, route_rid, bus_bid) values(?, ?, ?)";

        for(int i=2;i<=seatAvailable;i++) {
            query += ", (?, ?, ?)";
        }
        
        PreparedStatement stmt = conn.prepareStatement(query);
        int seatCount = 1;
        
        for(int i=1;i<seatAvailable*3;i+=3) {
            stmt.setInt(i, seatCount);
            stmt.setInt(i+1, routeId );
            stmt.setInt(i+2, busId);
            seatCount+=1;
        }
        
        stmt.executeUpdate();
        conn.close();
    }
}
