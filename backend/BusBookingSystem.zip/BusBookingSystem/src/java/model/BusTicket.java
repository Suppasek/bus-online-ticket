/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Natsu
 */
public class BusTicket {

    private int ticketId;
    private String ticketType;
    private float price;
    private int seatNumber;
    private BusTable route;
    private int paymentId;

    public BusTicket(int paymentId,int count) throws SQLException, ClassNotFoundException {
        this.paymentId = paymentId;
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        try (Connection conn = DriverManager.getConnection(sqllink, "root", "")) {
            PreparedStatement stmt = conn.prepareStatement("select * from bus_ticket where payment_pid = ? order by ticket_id asc");
            stmt.setInt(1, paymentId);
            ResultSet rs = stmt.executeQuery();
            rs.absolute(count);
            ticketId = rs.getInt("ticket_id");
            ticketType = rs.getString("ticket_type");
            price = rs.getFloat("ticket_price");
            stmt = conn.prepareStatement("select seat_number, route_rid from bus_seat where seat_id =?");
            stmt.setInt(1, rs.getInt("bus_seat_sid"));
            rs = stmt.executeQuery();
            rs.next();
            route = new BusTable(rs.getInt("route_rid"));
            seatNumber = rs.getInt("seat_number");
        }
    }

    public BusTicket(String TicketType, float price, int seatNumber, BusTable route, int paymentId) {
        this.ticketType = TicketType;
        this.price = price;
        this.seatNumber = seatNumber;
        this.route = route;
        this.paymentId = paymentId;
    }

    public int addTicket() throws ClassNotFoundException, SQLException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection(sqllink, "root", "")) {
            PreparedStatement stmt = conn.prepareStatement("select seat_id from bus_seat where route_rid = ? and seat_number = ?");
            stmt.setInt(1, route.getRouteId());
            stmt.setInt(2, seatNumber);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int seatId = rs.getInt("seat_id");
            stmt = conn.prepareStatement("insert into bus_ticket(ticket_type, ticket_price, bus_seat_sid, payment_pid) values(?, ?, ?, ?)");
            stmt.setString(1, ticketType);
            stmt.setFloat(2, price);
            stmt.setInt(3, seatId);
            stmt.setInt(4, paymentId);
            stmt.executeUpdate();
            stmt = conn.prepareStatement("update bus_seat set seat_available = ? where seat_id = ?");
            stmt.setInt(1, 1);
            stmt.setInt(2, seatId);
            stmt.executeUpdate();
            rs = stmt.executeQuery("select max(ticket_id) from bus_ticket");
            rs.next();
            ticketId = rs.getInt("max(ticket_id)");
            conn.close();
        }
        return ticketId;
        
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public BusTable getRoute() {
        return route;
    }

    public void setRoute(BusTable route) {
        this.route = route;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

}
