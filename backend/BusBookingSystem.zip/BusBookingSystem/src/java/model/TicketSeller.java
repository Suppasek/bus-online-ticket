/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;

/**
 *
 * @author Natsu
 */
public class TicketSeller extends User {
        
    private String employeeId;
    
    public TicketSeller() {
        
    }
    
    public TicketSeller(String userId) throws ClassNotFoundException, SQLException {
        super(userId);
    }
    
    public TicketSeller(String userId, String password, String firstName, String lastName, String phone, String email, String employeeId) {
        this.userId = userId;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.email = email;
        this.employeeId = employeeId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    
}
