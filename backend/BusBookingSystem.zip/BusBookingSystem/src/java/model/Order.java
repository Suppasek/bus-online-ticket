/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Natsu
 */
public class Order {
    private int paymentId;
    private String type;
    private float amount;
    private Timestamp paymentTime;
    private String[] selectedSeat;
    private BusTable route;
    private List<BusTicket> tickets;
    private String userId;
    private User user;
    
    public Order() {
        
    }
    
    public Order(String userId, int count) throws ClassNotFoundException, SQLException {
        this.userId = userId;
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection(sqllink, "root", "")) {
            PreparedStatement stmt = conn.prepareStatement("select * from payment where user_uid = ? order by payment_time desc");
            stmt.setString(1, userId);
            ResultSet rs = stmt.executeQuery();
            rs.absolute(count);
            paymentId = rs.getInt("payment_id");
            type = rs.getString("type");
            amount = rs.getFloat("amount");
            paymentTime = rs.getTimestamp("payment_time");
            tickets = new ArrayList<>();
            stmt = conn.prepareStatement("select * from bus_ticket where payment_pid = ? order by payment_pid asc");
            stmt.setInt(1, paymentId);
            rs = stmt.executeQuery();
            count = 1; 
            BusTicket ticketTemp;
            while (rs.next()) {
                ticketTemp = new BusTicket(paymentId, count);
                tickets.add(ticketTemp);
                count += 1;
            }
            
        }       
    }
    
    public Order(String type, float amount, String[] selectedSeat, BusTable route, User user) {
        this.type = type;
        this.amount = amount;
        this.paymentTime = new Timestamp(new java.util.Date().getTime());
        this.selectedSeat = selectedSeat;
        this.route = route;
        this.user = user;
    }
    
    public List insertOrder(String userType) throws ClassNotFoundException, SQLException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        List<Integer> busId = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(sqllink, "root", "")) {
            BusTicket ticketTemp;
            PreparedStatement stmt = conn.prepareStatement("insert into payment(type, amount, payment_time, user_uid) values(?, ?, ?, ?)");
            stmt.setString(1, type);
            stmt.setFloat(2, amount);
            stmt.setTimestamp(3, paymentTime);
            stmt.setString(4, user.getUserId());
            stmt.executeUpdate();
            stmt = conn.prepareStatement("select max(payment_id) from payment");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            for (String seat : selectedSeat) {
                ticketTemp = new BusTicket(userType, route.getBus().getBusType().getPrice(), Integer.parseInt(seat), route, rs.getInt("max(payment_id)"));
                busId.add(ticketTemp.addTicket());
            }
            conn.close();
        }
        return busId;
    }
 
    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Timestamp getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Timestamp paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String[] getSelectedSeat() {
        return selectedSeat;
    }

    public void setSelectedSeat(String[] selectedSeat) {
        this.selectedSeat = selectedSeat;
    }

    public BusTable getRoute() {
        return route;
    }

    public void setRoute(BusTable route) {
        this.route = route;
    }

    public List<BusTicket> getTickets() {
        return tickets;
    }

    public void setTickets(List<BusTicket> tickets) {
        this.tickets = tickets;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
}
