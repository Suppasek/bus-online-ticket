/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Natsu
 */
public class Customer extends User{
   
    private String address;
    
    public Customer() {
        
    }
    
    public Customer(String userId) throws ClassNotFoundException, SQLException {
        super(userId);
    }
    
    public Customer(String userId, String password, String firstName, String lastName, String phone, String email, String address) {
        this.userId = userId;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }
    
    public void insertCustomer() throws SQLException, ClassNotFoundException {
        String sqllink = "jdbc:mysql://localhost:3306/busbooking?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection(sqllink, "root", "")) {
            PreparedStatement stmt = conn.prepareStatement("insert into user values(?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, userId);
            stmt.setString(2, password);
            stmt.setString(3, firstName);
            stmt.setString(4, lastName);
            stmt.setString(5, email);
            stmt.setString(6, phone);
            stmt.setString(7, "customer");
            stmt.executeUpdate();
            stmt = conn.prepareStatement("insert into customer values(?, ?)");
            stmt.setString(1, userId);
            stmt.setString(2, address);
            stmt.executeUpdate();
        }
        
    }
    

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
}
